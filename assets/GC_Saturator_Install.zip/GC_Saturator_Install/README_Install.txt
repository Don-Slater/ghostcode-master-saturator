GHOSTCODE MASTER SATURATOR v1.0.0
Free — Ease Audio © 2026

MAC INSTALL:

AU (Logic, GarageBand):
Copy Ghostcode Master Saturator.component
to:
/Library/Audio/Plug-Ins/Components/

VST3 (Ableton, Bitwig, Reaper):
Copy Ghostcode Master Saturator.vst3
to:
/Library/Audio/Plug-Ins/VST3/

Restart your DAW.
Done.

Questions: ghostcode.audio@gmail.com
